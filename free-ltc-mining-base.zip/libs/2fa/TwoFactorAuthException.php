<?php

namespace RobThree\Auth;

use Exception;

class TwoFactorAuthException extends \Exception {}