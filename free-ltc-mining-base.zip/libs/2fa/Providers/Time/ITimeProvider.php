<?php

namespace RobThree\Auth\Providers\Time;

interface ITimeProvider
{
    public function getTime();
}